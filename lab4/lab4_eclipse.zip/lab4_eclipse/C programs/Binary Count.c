#define switches (volatile char *) 0x0002010
#define leds (char *) 0x0002000
void main()
{ *leds = 0x0000000;
    while (1)
     *leds = *leds + 1;
}
